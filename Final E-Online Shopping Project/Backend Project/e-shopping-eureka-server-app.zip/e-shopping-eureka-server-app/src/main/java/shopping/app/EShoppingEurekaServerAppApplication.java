package shopping.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EShoppingEurekaServerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EShoppingEurekaServerAppApplication.class, args);
	}

}
