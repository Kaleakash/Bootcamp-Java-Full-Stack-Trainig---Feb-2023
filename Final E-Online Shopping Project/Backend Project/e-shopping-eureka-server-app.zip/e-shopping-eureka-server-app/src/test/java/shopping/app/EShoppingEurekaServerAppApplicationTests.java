package shopping.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EShoppingEurekaServerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
