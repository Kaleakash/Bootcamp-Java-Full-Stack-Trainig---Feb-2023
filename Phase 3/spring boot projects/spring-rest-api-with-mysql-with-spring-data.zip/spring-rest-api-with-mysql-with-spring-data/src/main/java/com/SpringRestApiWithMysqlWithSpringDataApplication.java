package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestApiWithMysqlWithSpringDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestApiWithMysqlWithSpringDataApplication.class, args);
	}

}
